# Code style

Please make sure your editor picks up the [.clang-format](.clang-format) file.
